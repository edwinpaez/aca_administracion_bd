-- ============================================================
-- 02_datos_de_prueba.sql
-- Objetivo : cargar datos ficticios en las 7 tablas de negocio.
--            MOVIMIENTOS_INVENTARIO recibe 50.000 filas repartidas en
--            3 anios: sirven para la depuracion, la optimizacion
--            (indice) y el monitoreo del proyecto.
-- Ejecutar : conectado como TIENDA_APP en XEPDB1, DESPUES de 01.
-- Nota     : no es idempotente; correrlo dos veces duplica los datos
--            (y el UNIQUE de email lo detendra). Es solo para laboratorio.
-- ============================================================

DECLARE
  TYPE t_num IS TABLE OF NUMBER;
  v_cat    t_num;
  v_emp    t_num;
  v_cli    t_num;
  v_prod   t_num;
  v_precio t_num;
  v_ped    NUMBER;
  v_i      NUMBER;
  v_k      NUMBER;
  v_r      NUMBER;
  v_tipo   VARCHAR2(10);
  v_estado VARCHAR2(15);
  v_ncat   NUMBER;
  v_nemp   NUMBER;
  v_ncli   NUMBER;
  v_nprod  NUMBER;
BEGIN
  -- Categorias
  INSERT INTO categorias (nombre) VALUES ('Bebidas');
  INSERT INTO categorias (nombre) VALUES ('Snacks');
  INSERT INTO categorias (nombre) VALUES ('Lacteos');
  INSERT INTO categorias (nombre) VALUES ('Aseo');
  INSERT INTO categorias (nombre) VALUES ('Panaderia');

  -- Empleados
  FOR i IN 1..5 LOOP
    INSERT INTO empleados (nombre, cargo, fecha_ingreso)
    VALUES ('Empleado ' || i,
            CASE MOD(i, 3) WHEN 0 THEN 'Cajero' WHEN 1 THEN 'Bodeguero' ELSE 'Vendedor' END,
            ADD_MONTHS(SYSDATE, -12 * i));
  END LOOP;

  -- Clientes
  FOR i IN 1..20 LOOP
    INSERT INTO clientes (nombre, telefono, email)
    VALUES ('Cliente ' || i, '300' || LPAD(i, 7, '0'), 'cliente' || i || '@correo.test');
  END LOOP;

  SELECT id_categoria BULK COLLECT INTO v_cat FROM categorias ORDER BY id_categoria;
  SELECT id_empleado  BULK COLLECT INTO v_emp FROM empleados  ORDER BY id_empleado;
  SELECT id_cliente   BULK COLLECT INTO v_cli FROM clientes   ORDER BY id_cliente;
  -- .COUNT no se puede usar dentro de un INSERT: se guarda antes en variables
  v_ncat := v_cat.COUNT;
  v_nemp := v_emp.COUNT;
  v_ncli := v_cli.COUNT;

  -- Productos
  FOR i IN 1..30 LOOP
    INSERT INTO productos (nombre, id_categoria, precio, stock_actual)
    VALUES ('Producto ' || i, v_cat(MOD(i, v_ncat) + 1),
            ROUND(DBMS_RANDOM.VALUE(1000, 20000), -2),
            TRUNC(DBMS_RANDOM.VALUE(50, 500)));
  END LOOP;

  SELECT id_producto, precio BULK COLLECT INTO v_prod, v_precio
    FROM productos ORDER BY id_producto;
  v_nprod := v_prod.COUNT;

  -- Pedidos (300) con 1 a 3 lineas de detalle cada uno
  FOR i IN 1..300 LOOP
    v_r := DBMS_RANDOM.VALUE(0, 1);
    v_estado := CASE WHEN v_r < 0.70 THEN 'ENTREGADO'
                     WHEN v_r < 0.90 THEN 'PENDIENTE'
                     ELSE 'ANULADO' END;
    INSERT INTO pedidos (id_cliente, fecha_pedido, estado)
    VALUES (v_cli(TRUNC(DBMS_RANDOM.VALUE(1, v_ncli + 1))),
            SYSDATE - DBMS_RANDOM.VALUE(0, 365), v_estado)
    RETURNING id_pedido INTO v_ped;

    FOR j IN 1..TRUNC(DBMS_RANDOM.VALUE(1, 4)) LOOP
      v_k := TRUNC(DBMS_RANDOM.VALUE(1, v_nprod + 1));
      INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario)
      VALUES (v_ped, v_prod(v_k), TRUNC(DBMS_RANDOM.VALUE(1, 11)), v_precio(v_k));
    END LOOP;
  END LOOP;

  -- Movimientos de inventario (50.000, ultimos 3 anios)
  FOR i IN 1..50000 LOOP
    v_r := DBMS_RANDOM.VALUE(0, 1);
    v_tipo := CASE WHEN v_r < 0.45 THEN 'ENTRADA'
                   WHEN v_r < 0.90 THEN 'SALIDA'
                   ELSE 'AJUSTE' END;
    INSERT INTO movimientos_inventario
      (id_producto, id_empleado, tipo, cantidad, fecha_movimiento, observacion)
    VALUES (v_prod(TRUNC(DBMS_RANDOM.VALUE(1, v_nprod + 1))),
            v_emp(TRUNC(DBMS_RANDOM.VALUE(1, v_nemp + 1))),
            v_tipo, TRUNC(DBMS_RANDOM.VALUE(1, 51)),
            SYSDATE - DBMS_RANDOM.VALUE(0, 1095), 'Dato de prueba');
  END LOOP;

  COMMIT;
END;
/

-- ---------- Validacion ----------
-- Esperado: categorias 5, empleados 5, clientes 20, productos 30,
-- pedidos 300, detalle_pedido entre 300 y 900, movimientos_inventario 50000
SELECT 'CATEGORIAS' AS tabla, COUNT(*) AS filas FROM categorias
UNION ALL SELECT 'EMPLEADOS', COUNT(*) FROM empleados
UNION ALL SELECT 'CLIENTES', COUNT(*) FROM clientes
UNION ALL SELECT 'PRODUCTOS', COUNT(*) FROM productos
UNION ALL SELECT 'PEDIDOS', COUNT(*) FROM pedidos
UNION ALL SELECT 'DETALLE_PEDIDO', COUNT(*) FROM detalle_pedido
UNION ALL SELECT 'MOVIMIENTOS_INVENTARIO', COUNT(*) FROM movimientos_inventario;

-- Distribucion por antiguedad (util para definir la depuracion)
SELECT CASE WHEN fecha_movimiento < ADD_MONTHS(SYSDATE, -12) THEN 'mas de 12 meses'
            ELSE 'ultimos 12 meses' END AS antiguedad,
       COUNT(*) AS filas
  FROM movimientos_inventario
 GROUP BY CASE WHEN fecha_movimiento < ADD_MONTHS(SYSDATE, -12) THEN 'mas de 12 meses'
               ELSE 'ultimos 12 meses' END;

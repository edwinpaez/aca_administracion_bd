-- ============================================================
-- 04_archivelog_y_fra.sql
-- Objetivo : (A) configurar la zona de recuperacion (FRA) y
--            (B) pasar la base a modo ARCHIVELOG para poder recuperar
--            sin perder transacciones.
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA), en la raiz.
-- ATENCION : este script REINICIA la base de datos (SHUTDOWN IMMEDIATE +
--            STARTUP MOUNT). Dura 1-2 minutos y cierra todas las sesiones.
--            Cierra otras ventanas de SQL*Plus antes de ejecutarlo.
-- Salida   : C:\Proyecto_Oracle\evidencias\04_archivelog.txt
-- Nota     : la FRA queda en la misma unidad C: que la base. Sirve para el
--            laboratorio; en produccion iria en un disco o equipo distinto.
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
COLUMN name FORMAT A90
COLUMN value FORMAT A60

SPOOL C:\Proyecto_Oracle\evidencias\04_archivelog.txt

PROMPT ===== Estado ANTES =====
SELECT log_mode FROM v$database;

-- ---------- A. Zona de recuperacion (no requiere reinicio) ----------
HOST mkdir C:\Proyecto_Oracle\respaldo\fra

-- El tamano se define PRIMERO; luego el destino
ALTER SYSTEM SET db_recovery_file_dest_size = 5G SCOPE = BOTH;
ALTER SYSTEM SET db_recovery_file_dest = 'C:\Proyecto_Oracle\respaldo\fra' SCOPE = BOTH;

-- ---------- B. Pasar a ARCHIVELOG (requiere reinicio) ----------
SHUTDOWN IMMEDIATE
STARTUP MOUNT
ALTER DATABASE ARCHIVELOG;
ALTER DATABASE OPEN;

-- La PDB suele abrirse sola (SAVE STATE); si ya esta abierta se ignora el error ORA-65019
BEGIN
  EXECUTE IMMEDIATE 'ALTER PLUGGABLE DATABASE xepdb1 OPEN';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE NOT IN (-65019, -65020) THEN RAISE; END IF;
END;
/

-- ---------- Validacion ----------
PROMPT ===== Estado DESPUES =====
SELECT log_mode FROM v$database;
SELECT name, open_mode FROM v$pdbs;
SHOW PARAMETER db_recovery_file_dest
SELECT name, ROUND(space_limit/1024/1024) AS limite_mb, ROUND(space_used/1024/1024) AS usado_mb
  FROM v$recovery_file_dest;

-- Forzar un archivado para comprobar que funciona
ALTER SYSTEM ARCHIVE LOG CURRENT;
SELECT sequence#, name FROM v$archived_log ORDER BY sequence#;

SPOOL OFF
PROMPT Evidencia guardada en C:\Proyecto_Oracle\evidencias\04_archivelog.txt

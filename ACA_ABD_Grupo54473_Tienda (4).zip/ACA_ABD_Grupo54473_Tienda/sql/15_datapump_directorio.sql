-- ============================================================
-- 15_datapump_directorio.sql
-- Objetivo : preparar la exportacion logica (Data Pump) del esquema TIENDA_APP,
--            que es el "archivo de respaldo de la base" pedido en Moodle (punto 6).
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA), ANTES de 15_exportar_datapump.bat
-- Salida   : C:\Proyecto_Oracle\evidencias\15_datapump_directorio.txt
-- Hace     : crea la carpeta de Oracle (DIRECTORY) DP_TIENDA y da permiso a TIENDA_APP.
-- Nota     : la carpeta C:\Proyecto_Oracle\respaldo\datapump debe existir
--            (el .bat la crea; si ejecutas este script primero, crea la carpeta a mano).
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
COLUMN directory_name FORMAT A14
COLUMN directory_path FORMAT A55
SPOOL C:\Proyecto_Oracle\evidencias\15_datapump_directorio.txt

ALTER SESSION SET CONTAINER = xepdb1;

CREATE OR REPLACE DIRECTORY dp_tienda AS 'C:\Proyecto_Oracle\respaldo\datapump';
GRANT READ, WRITE ON DIRECTORY dp_tienda TO tienda_app;

SELECT directory_name, directory_path FROM dba_directories WHERE directory_name = 'DP_TIENDA';
SELECT grantee, privilege FROM dba_tab_privs WHERE table_name = 'DP_TIENDA' ORDER BY privilege;

SPOOL OFF
PROMPT Listo. Siguiente: ejecutar 15_exportar_datapump.bat (pide la clave de TIENDA_APP).

-- ============================================================
-- 01_modelo_y_tablas.sql
-- Objetivo : crear las 9 tablas del esquema (Oracle 18c)
-- Ejecutar : conectado como el usuario de la aplicacion (no SYS),
--            dentro de la PDB (ej. XEPDB1), DESPUES de 00_entorno.sql
-- Orden    : 1o de los scripts de objetos
-- ============================================================

-- Si necesitas recrear todo (DESTRUCTIVO, solo en laboratorio):
-- DROP TABLE auditoria_permisos CASCADE CONSTRAINTS;
-- DROP TABLE log_depuracion_inventario CASCADE CONSTRAINTS;
-- DROP TABLE movimientos_inventario CASCADE CONSTRAINTS;
-- DROP TABLE detalle_pedido CASCADE CONSTRAINTS;
-- DROP TABLE pedidos CASCADE CONSTRAINTS;
-- DROP TABLE productos CASCADE CONSTRAINTS;
-- DROP TABLE categorias CASCADE CONSTRAINTS;
-- DROP TABLE empleados CASCADE CONSTRAINTS;
-- DROP TABLE clientes CASCADE CONSTRAINTS;

-- ---------- VENTAS ----------
CREATE TABLE clientes (
  id_cliente  NUMBER GENERATED ALWAYS AS IDENTITY,
  nombre      VARCHAR2(100) NOT NULL,
  telefono    VARCHAR2(20),
  email       VARCHAR2(100),
  CONSTRAINT pk_clientes PRIMARY KEY (id_cliente),
  CONSTRAINT uq_clientes_email UNIQUE (email)
);

CREATE TABLE pedidos (
  id_pedido     NUMBER GENERATED ALWAYS AS IDENTITY,
  id_cliente    NUMBER NOT NULL,
  fecha_pedido  DATE DEFAULT SYSDATE NOT NULL,
  estado        VARCHAR2(15) DEFAULT 'PENDIENTE' NOT NULL,
  CONSTRAINT pk_pedidos PRIMARY KEY (id_pedido),
  CONSTRAINT fk_pedidos_clientes FOREIGN KEY (id_cliente) REFERENCES clientes (id_cliente),
  CONSTRAINT ck_pedidos_estado CHECK (estado IN ('PENDIENTE','ENTREGADO','ANULADO'))
);

-- ---------- INVENTARIO ----------
CREATE TABLE categorias (
  id_categoria  NUMBER GENERATED ALWAYS AS IDENTITY,
  nombre        VARCHAR2(60) NOT NULL,
  CONSTRAINT pk_categorias PRIMARY KEY (id_categoria),
  CONSTRAINT uq_categorias_nombre UNIQUE (nombre)
);

CREATE TABLE productos (
  id_producto   NUMBER GENERATED ALWAYS AS IDENTITY,
  nombre        VARCHAR2(100) NOT NULL,
  id_categoria  NUMBER NOT NULL,
  precio        NUMBER(10,2) NOT NULL,
  stock_actual  NUMBER(8) DEFAULT 0 NOT NULL,
  CONSTRAINT pk_productos PRIMARY KEY (id_producto),
  CONSTRAINT fk_productos_categorias FOREIGN KEY (id_categoria) REFERENCES categorias (id_categoria),
  CONSTRAINT ck_productos_precio CHECK (precio >= 0),
  CONSTRAINT ck_productos_stock CHECK (stock_actual >= 0)
);

CREATE TABLE detalle_pedido (
  id_detalle_pedido  NUMBER GENERATED ALWAYS AS IDENTITY,
  id_pedido          NUMBER NOT NULL,
  id_producto        NUMBER NOT NULL,
  cantidad           NUMBER(6) NOT NULL,
  precio_unitario    NUMBER(10,2) NOT NULL,
  CONSTRAINT pk_detalle_pedido PRIMARY KEY (id_detalle_pedido),
  CONSTRAINT fk_detped_pedidos FOREIGN KEY (id_pedido) REFERENCES pedidos (id_pedido),
  CONSTRAINT fk_detped_productos FOREIGN KEY (id_producto) REFERENCES productos (id_producto),
  CONSTRAINT ck_detped_cantidad CHECK (cantidad > 0)
);

-- ---------- PERSONAL ----------
CREATE TABLE empleados (
  id_empleado    NUMBER GENERATED ALWAYS AS IDENTITY,
  nombre         VARCHAR2(100) NOT NULL,
  cargo          VARCHAR2(50),
  fecha_ingreso  DATE DEFAULT SYSDATE,
  CONSTRAINT pk_empleados PRIMARY KEY (id_empleado)
);

CREATE TABLE movimientos_inventario (
  id_movimiento     NUMBER GENERATED ALWAYS AS IDENTITY,
  id_producto       NUMBER NOT NULL,
  id_empleado       NUMBER NOT NULL,
  tipo              VARCHAR2(10) NOT NULL,
  cantidad          NUMBER(8) NOT NULL,
  fecha_movimiento  DATE DEFAULT SYSDATE NOT NULL,
  observacion       VARCHAR2(200),
  CONSTRAINT pk_movimientos PRIMARY KEY (id_movimiento),
  CONSTRAINT fk_mov_productos FOREIGN KEY (id_producto) REFERENCES productos (id_producto),
  CONSTRAINT fk_mov_empleados FOREIGN KEY (id_empleado) REFERENCES empleados (id_empleado),
  CONSTRAINT ck_mov_tipo CHECK (tipo IN ('ENTRADA','SALIDA','AJUSTE')),
  CONSTRAINT ck_mov_cantidad CHECK (cantidad > 0)
);

-- ---------- ADMINISTRACION Y DBA ----------
CREATE TABLE log_depuracion_inventario (
  id_log                NUMBER GENERATED ALWAYS AS IDENTITY,
  fecha_ejecucion       DATE DEFAULT SYSDATE NOT NULL,
  registros_eliminados  NUMBER DEFAULT 0 NOT NULL,
  estado                VARCHAR2(10) NOT NULL,
  mensaje               VARCHAR2(300),
  CONSTRAINT pk_log_depuracion PRIMARY KEY (id_log),
  CONSTRAINT ck_log_estado CHECK (estado IN ('OK','ERROR'))
);

CREATE TABLE auditoria_permisos (
  id_auditoria  NUMBER GENERATED ALWAYS AS IDENTITY,
  fecha_accion  DATE DEFAULT SYSDATE NOT NULL,
  usuario_bd    VARCHAR2(60) NOT NULL,
  accion        VARCHAR2(30) NOT NULL,
  objeto        VARCHAR2(100),
  detalle       VARCHAR2(300),
  CONSTRAINT pk_auditoria_permisos PRIMARY KEY (id_auditoria)
);

-- Indices sobre llaves foraneas de uso frecuente
CREATE INDEX ix_pedidos_cliente  ON pedidos (id_cliente);
CREATE INDEX ix_productos_cat    ON productos (id_categoria);
CREATE INDEX ix_detped_pedido    ON detalle_pedido (id_pedido);
CREATE INDEX ix_detped_producto  ON detalle_pedido (id_producto);
-- (ix de movimientos_inventario se crea mas adelante como parte de la optimizacion)

-- Validacion: deben aparecer 9 tablas
SELECT table_name FROM user_tables ORDER BY table_name;

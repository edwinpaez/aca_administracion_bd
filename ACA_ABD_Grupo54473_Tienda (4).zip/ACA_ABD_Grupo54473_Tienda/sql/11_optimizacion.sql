-- ============================================================
-- 11_optimizacion.sql
-- Objetivo : demostrar con medidas reales (plan y lecturas logicas) el efecto
--            de un indice sobre MOVIMIENTOS_INVENTARIO, la tabla mas grande
--            (50.000 filas). ANTES -> sin indice; DESPUES -> con indice.
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA). Se ejecuta ANTES de la
--            depuracion automatica (script 12), que reduce las filas.
-- Salida   : C:\Proyecto_Oracle\evidencias\11_optimizacion.txt
-- Re-ejecutable: borra el indice de prueba si ya existe.
-- Que buscar: en ANTES el plan es TABLE ACCESS FULL con muchos "Buffers";
--            en DESPUES usa el indice (INDEX RANGE SCAN) y los Buffers bajan.
-- ============================================================
SET LINESIZE 220
SET PAGESIZE 200
SET TRIMSPOOL ON
SET SERVEROUTPUT OFF
SET TIMING ON
COLUMN plan_table_output FORMAT A200
SPOOL C:\Proyecto_Oracle\evidencias\11_optimizacion.txt

ALTER SESSION SET CONTAINER = xepdb1;
ALTER SESSION SET CURRENT_SCHEMA = tienda_app;

PROMPT ===== 0. Preparacion: sin indice previo y estadisticas frescas =====
BEGIN
  FOR i IN (SELECT index_name FROM dba_indexes
             WHERE owner = 'TIENDA_APP' AND index_name = 'IX_MOV_FECHA_PROD') LOOP
    EXECUTE IMMEDIATE 'DROP INDEX tienda_app.ix_mov_fecha_prod';
  END LOOP;
  DBMS_STATS.GATHER_TABLE_STATS('TIENDA_APP', 'MOVIMIENTOS_INVENTARIO', cascade => TRUE);
END;
/
SELECT index_name FROM dba_indexes
 WHERE owner = 'TIENDA_APP' AND table_name = 'MOVIMIENTOS_INVENTARIO';
SELECT COUNT(*) AS filas_total,
       SUM(CASE WHEN fecha_movimiento >= TRUNC(SYSDATE) - 30 THEN 1 ELSE 0 END) AS ultimos_30_dias
  FROM movimientos_inventario;

PROMPT ===== 1. ANTES - consulta A: movimientos de un producto en los ultimos 30 dias =====
SELECT /*+ GATHER_PLAN_STATISTICS */ COUNT(*) AS movs, NVL(SUM(cantidad),0) AS unidades
  FROM movimientos_inventario
 WHERE fecha_movimiento >= TRUNC(SYSDATE) - 30 AND id_producto = 7;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(NULL, NULL, 'ALLSTATS LAST'));

PROMPT ===== 2. ANTES - consulta B: todos los movimientos de los ultimos 30 dias =====
SELECT /*+ GATHER_PLAN_STATISTICS */ COUNT(*) AS movs
  FROM movimientos_inventario
 WHERE fecha_movimiento >= TRUNC(SYSDATE) - 30;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(NULL, NULL, 'ALLSTATS LAST'));

PROMPT ===== 3. Crear el indice (fecha primero: sirve a rangos de fecha y a fecha+producto) =====
CREATE INDEX ix_mov_fecha_prod ON movimientos_inventario (fecha_movimiento, id_producto);
SELECT index_name, status FROM dba_indexes
 WHERE owner = 'TIENDA_APP' AND table_name = 'MOVIMIENTOS_INVENTARIO';

PROMPT ===== 4. DESPUES - consulta A =====
SELECT /*+ GATHER_PLAN_STATISTICS */ COUNT(*) AS movs, NVL(SUM(cantidad),0) AS unidades
  FROM movimientos_inventario
 WHERE fecha_movimiento >= TRUNC(SYSDATE) - 30 AND id_producto = 7;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(NULL, NULL, 'ALLSTATS LAST'));

PROMPT ===== 5. DESPUES - consulta B =====
SELECT /*+ GATHER_PLAN_STATISTICS */ COUNT(*) AS movs
  FROM movimientos_inventario
 WHERE fecha_movimiento >= TRUNC(SYSDATE) - 30;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(NULL, NULL, 'ALLSTATS LAST'));

SET TIMING OFF
SPOOL OFF
PROMPT Listo. Compara Buffers y Operation entre ANTES (pasos 1-2) y DESPUES (pasos 4-5).

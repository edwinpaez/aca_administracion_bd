-- ============================================================
-- 00_entorno.sql
-- Objetivo : crear en la PDB XEPDB1 el tablespace y el usuario
--            de la aplicacion (TIENDA_APP) para el proyecto.
-- Ejecutar : en SQL*Plus conectado como  "/ as sysdba"  (raiz XE),
--            ANTES de 01_modelo_y_tablas.sql
-- Nota     : pide la contrasena por consola (no queda en el archivo).
--            No uses & ni comillas en la contrasena.
-- No es idempotente: si ya existe el tablespace o el usuario, dara error.
-- ============================================================

-- Que la PDB quede abierta automaticamente tras reiniciar Windows
ALTER PLUGGABLE DATABASE xepdb1 SAVE STATE;

-- Trabajar dentro de la PDB
ALTER SESSION SET CONTAINER = xepdb1;

-- Tablespace propio del proyecto (misma carpeta de los datafiles de la PDB)
DECLARE
  v_dir VARCHAR2(260);
BEGIN
  SELECT SUBSTR(file_name, 1, INSTR(file_name, '\', -1))
    INTO v_dir
    FROM dba_data_files
   WHERE tablespace_name = 'USERS';

  EXECUTE IMMEDIATE
    'CREATE TABLESPACE ts_tienda DATAFILE ''' || v_dir || 'ts_tienda01.dbf'' ' ||
    'SIZE 100M AUTOEXTEND ON NEXT 10M MAXSIZE 500M';
END;
/

-- Usuario de la aplicacion
ACCEPT pwd CHAR PROMPT 'Contrasena para TIENDA_APP (no se muestra): ' HIDE

CREATE USER tienda_app IDENTIFIED BY "&pwd"
  DEFAULT TABLESPACE ts_tienda
  QUOTA UNLIMITED ON ts_tienda;

GRANT CREATE SESSION, CREATE TABLE, CREATE SEQUENCE, CREATE VIEW,
      CREATE PROCEDURE, CREATE TRIGGER, CREATE JOB
   TO tienda_app;

-- ---------- Validacion ----------
COLUMN file_name FORMAT A80
COLUMN username FORMAT A15
SELECT username, default_tablespace FROM dba_users WHERE username = 'TIENDA_APP';
SELECT tablespace_name, file_name, bytes/1024/1024 AS mb
  FROM dba_data_files WHERE tablespace_name = 'TS_TIENDA';
SHOW CON_NAME

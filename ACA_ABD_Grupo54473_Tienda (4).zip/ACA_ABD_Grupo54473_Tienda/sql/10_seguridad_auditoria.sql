-- ============================================================
-- 10_seguridad_auditoria.sql
-- Objetivo : (1) seguridad por minimo privilegio: perfil de claves, roles por
--            funcion, usuarios, GRANT y REVOKE; (2) auditoria unificada de
--            cambios de permisos y de DML sobre CLIENTES; (3) prueba de que
--            un permiso denegado falla y queda registrado.
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA). Pide UNA clave oculta que se
--            usa para los 3 usuarios de laboratorio (usr_ventas,
--            usr_inventario, usr_auditor). No pegues la clave en el chat.
-- Salida   : C:\Proyecto_Oracle\evidencias\10_seguridad_auditoria.txt
-- Re-ejecutable: el bloque 0 borra lo creado por este script (solo objetos
--            de laboratorio: usuarios usr_*, roles rol_*, perfil y politicas).
-- Nota     : el spool puede mostrar la clave si la escribes visible; el
--            ACCEPT usa HIDE y SET VERIFY OFF evita el eco.
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
SET VERIFY OFF
COLUMN dbusername FORMAT A15
COLUMN action_name FORMAT A14
COLUMN objeto FORMAT A28
COLUMN grantee FORMAT A16
COLUMN granted_role FORMAT A16
COLUMN privilege FORMAT A16
COLUMN table_name FORMAT A22
COLUMN username FORMAT A16
COLUMN profile FORMAT A14
COLUMN account_status FORMAT A12
COLUMN accion FORMAT A14
COLUMN usuario_bd FORMAT A15
COLUMN detalle FORMAT A70
ACCEPT pwd CHAR PROMPT 'Clave para los usuarios usr_* (oculta): ' HIDE
SPOOL C:\Proyecto_Oracle\evidencias\10_seguridad_auditoria.txt

ALTER SESSION SET CONTAINER = xepdb1;
COLUMN t_ini NEW_VALUE v_ini NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS') AS t_ini FROM dual;
SELECT 'Inicio: ' || '&v_ini' AS inicio FROM dual;

PROMPT ===== 0. Limpieza previa (solo objetos de este script) =====
BEGIN
  FOR u IN (SELECT username FROM dba_users
             WHERE username IN ('USR_VENTAS','USR_INVENTARIO','USR_AUDITOR')) LOOP
    EXECUTE IMMEDIATE 'DROP USER ' || u.username || ' CASCADE';
  END LOOP;
  FOR r IN (SELECT role FROM dba_roles
             WHERE role IN ('ROL_VENTAS','ROL_INVENTARIO','ROL_AUDITOR')) LOOP
    EXECUTE IMMEDIATE 'DROP ROLE ' || r.role;
  END LOOP;
  FOR p IN (SELECT profile FROM dba_profiles
             WHERE profile = 'PERFIL_TIENDA' AND ROWNUM = 1) LOOP
    EXECUTE IMMEDIATE 'DROP PROFILE perfil_tienda';
  END LOOP;
  FOR a IN (SELECT policy_name FROM audit_unified_policies
             WHERE policy_name IN ('POL_CAMBIO_PERMISOS','POL_DML_CLIENTES')
             GROUP BY policy_name) LOOP
    BEGIN EXECUTE IMMEDIATE 'NOAUDIT POLICY ' || a.policy_name; EXCEPTION WHEN OTHERS THEN NULL; END;
    EXECUTE IMMEDIATE 'DROP AUDIT POLICY ' || a.policy_name;
  END LOOP;
END;
/

PROMPT ===== 1. Auditoria: politicas (se activan ANTES de crear usuarios y permisos) =====
CREATE AUDIT POLICY pol_cambio_permisos
  ACTIONS CREATE USER, ALTER USER, DROP USER, CREATE ROLE, ALTER ROLE, DROP ROLE, GRANT, REVOKE;
CREATE AUDIT POLICY pol_dml_clientes
  ACTIONS INSERT ON tienda_app.clientes, UPDATE ON tienda_app.clientes, DELETE ON tienda_app.clientes;
AUDIT POLICY pol_cambio_permisos;
AUDIT POLICY pol_dml_clientes;

PROMPT ===== 2. Perfil de seguridad de claves =====
CREATE PROFILE perfil_tienda LIMIT
  FAILED_LOGIN_ATTEMPTS 5
  PASSWORD_LOCK_TIME    1/24
  PASSWORD_LIFE_TIME    90
  SESSIONS_PER_USER     3;

PROMPT ===== 3. Roles por funcion (minimo privilegio) =====
CREATE ROLE rol_ventas;
CREATE ROLE rol_inventario;
CREATE ROLE rol_auditor;

GRANT CREATE SESSION TO rol_ventas, rol_inventario, rol_auditor;

-- Ventas: opera clientes y pedidos; solo lee el catalogo. No borra clientes.
GRANT SELECT, INSERT, UPDATE ON tienda_app.clientes        TO rol_ventas;
GRANT SELECT, INSERT, UPDATE ON tienda_app.pedidos         TO rol_ventas;
GRANT SELECT, INSERT, UPDATE ON tienda_app.detalle_pedido  TO rol_ventas;
GRANT SELECT ON tienda_app.productos   TO rol_ventas;
GRANT SELECT ON tienda_app.categorias  TO rol_ventas;

-- Inventario: registra movimientos y ajusta productos; no ve clientes.
GRANT SELECT, INSERT ON tienda_app.movimientos_inventario TO rol_inventario;
GRANT SELECT, UPDATE ON tienda_app.productos              TO rol_inventario;
GRANT SELECT ON tienda_app.categorias                     TO rol_inventario;

-- Auditor: solo lectura de todo y de la auditoria.
GRANT SELECT ON tienda_app.clientes                 TO rol_auditor;
GRANT SELECT ON tienda_app.pedidos                  TO rol_auditor;
GRANT SELECT ON tienda_app.movimientos_inventario   TO rol_auditor;
GRANT SELECT ON tienda_app.auditoria_permisos       TO rol_auditor;
GRANT SELECT ON tienda_app.log_depuracion_inventario TO rol_auditor;

PROMPT ===== 4. Usuarios de laboratorio =====
CREATE USER usr_ventas     IDENTIFIED BY "&pwd" PROFILE perfil_tienda;
CREATE USER usr_inventario IDENTIFIED BY "&pwd" PROFILE perfil_tienda;
CREATE USER usr_auditor    IDENTIFIED BY "&pwd" PROFILE perfil_tienda;
GRANT rol_ventas     TO usr_ventas;
GRANT rol_inventario TO usr_inventario;
GRANT rol_auditor    TO usr_auditor;

PROMPT ===== 5. REVOKE: se concede DELETE de mas y se retira (demuestra el control) =====
GRANT DELETE ON tienda_app.pedidos TO rol_ventas;
SELECT privilege, table_name FROM dba_tab_privs
 WHERE grantee = 'ROL_VENTAS' AND table_name = 'PEDIDOS' ORDER BY privilege;
REVOKE DELETE ON tienda_app.pedidos FROM rol_ventas;
SELECT privilege, table_name FROM dba_tab_privs
 WHERE grantee = 'ROL_VENTAS' AND table_name = 'PEDIDOS' ORDER BY privilege;

PROMPT ===== 6. Resultado: roles, privilegios y usuarios =====
SELECT grantee, granted_role FROM dba_role_privs
 WHERE grantee LIKE 'USR\_%' ESCAPE '\' ORDER BY grantee;
SELECT grantee, privilege, table_name FROM dba_tab_privs
 WHERE grantee LIKE 'ROL\_%' ESCAPE '\' ORDER BY grantee, table_name, privilege;
SELECT username, profile, account_status FROM dba_users
 WHERE username LIKE 'USR\_%' ESCAPE '\' ORDER BY username;

PROMPT ===== 7. Prueba: usr_ventas (permitido y denegado) =====
CONNECT usr_ventas/"&pwd"@localhost:1521/XEPDB1
SHOW USER
PROMPT -- Permitido: leer y actualizar clientes (se revierte)
SELECT COUNT(*) AS clientes_visibles FROM tienda_app.clientes;
UPDATE tienda_app.clientes SET telefono = telefono WHERE id_cliente = 1;
ROLLBACK;
PROMPT -- Denegado: borrar clientes (se espera ORA-01031)
DELETE FROM tienda_app.clientes WHERE id_cliente = 21;
PROMPT -- Denegado: leer movimientos de inventario (se espera ORA-00942)
SELECT COUNT(*) FROM tienda_app.movimientos_inventario;

PROMPT ===== 8. Prueba: usr_inventario (permitido y denegado) =====
CONNECT usr_inventario/"&pwd"@localhost:1521/XEPDB1
SHOW USER
SELECT COUNT(*) AS movimientos_visibles FROM tienda_app.movimientos_inventario;
PROMPT -- Denegado: leer clientes (se espera ORA-00942)
SELECT COUNT(*) FROM tienda_app.clientes;

PROMPT ===== 9. Volver a SYSDBA y registrar la auditoria =====
CONNECT / AS SYSDBA
ALTER SESSION SET CONTAINER = xepdb1;
EXEC DBMS_AUDIT_MGMT.FLUSH_UNIFIED_AUDIT_TRAIL;

SELECT TO_CHAR(event_timestamp,'HH24:MI:SS') AS hora, dbusername, action_name,
       NVL(object_schema||'.'||object_name, '-') AS objeto, return_code
  FROM unified_audit_trail
 WHERE event_timestamp >= TO_TIMESTAMP('&v_ini','YYYY-MM-DD HH24:MI:SS')
   AND (unified_audit_policies LIKE '%POL_CAMBIO_PERMISOS%'
     OR unified_audit_policies LIKE '%POL_DML_CLIENTES%')
 ORDER BY event_timestamp;

-- Copia legible de la auditoria en la tabla del proyecto (AUDITORIA_PERMISOS)
INSERT INTO tienda_app.auditoria_permisos (fecha_accion, usuario_bd, accion, objeto, detalle)
SELECT CAST(event_timestamp AS DATE), NVL(dbusername,'?'), SUBSTR(action_name,1,30),
       SUBSTR(NVL(object_schema||'.'||object_name, '-'),1,100),
       SUBSTR('rc=' || return_code || ' ' || REPLACE(sql_text, CHR(10), ' '),1,300)
  FROM unified_audit_trail
 WHERE event_timestamp >= TO_TIMESTAMP('&v_ini','YYYY-MM-DD HH24:MI:SS')
   AND (unified_audit_policies LIKE '%POL_CAMBIO_PERMISOS%'
     OR unified_audit_policies LIKE '%POL_DML_CLIENTES%');
COMMIT;

SELECT COUNT(*) AS filas_en_auditoria_permisos FROM tienda_app.auditoria_permisos;
SELECT usuario_bd, accion, objeto, SUBSTR(detalle,1,70) AS detalle
  FROM tienda_app.auditoria_permisos
 WHERE accion IN ('DELETE','UPDATE') ORDER BY id_auditoria;

SPOOL OFF
PROMPT Listo. Esperado: 3 usuarios con su rol; DELETE de usr_ventas rechazado (ORA-01031) y auditado.

-- ============================================================
-- 07_simular_falla.sql        *** DESTRUCTIVO (solo laboratorio) ***
-- Objetivo : simular la perdida fisica del datafile del tablespace
--            TS_TIENDA (el que contiene todas las tablas del proyecto).
-- Antes de ejecutar: haber corrido 05 (respaldo) y 06 (marca).
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA).
-- Seguridad: (1) saca el tablespace de linea, (2) hace una copia extra del
--            archivo en C:\Proyecto_Oracle\respaldo, (3) PIDE CONFIRMACION
--            con PAUSE antes de borrar. Ctrl+C en ese momento cancela.
-- Salida   : C:\Proyecto_Oracle\evidencias\07_simular_falla.txt
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
COLUMN tablespace_name FORMAT A18
SPOOL C:\Proyecto_Oracle\evidencias\07_simular_falla.txt

SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS inicio_falla FROM dual;
ALTER SESSION SET CONTAINER = xepdb1;

PROMPT ===== 1. Sacar TS_TIENDA de linea (permite tocar el archivo con la BD abierta) =====
ALTER TABLESPACE ts_tienda OFFLINE IMMEDIATE;
SELECT tablespace_name, status FROM dba_tablespaces WHERE tablespace_name = 'TS_TIENDA';

PROMPT ===== 2. Copia extra de seguridad del datafile (red de seguridad) =====
HOST copy "C:\APP\PETROSKY\PRODUCT\21C\ORADATA\XE\XEPDB1\TS_TIENDA01.DBF" "C:\Proyecto_Oracle\respaldo\TS_TIENDA01_copia_seguridad.DBF"
HOST dir "C:\Proyecto_Oracle\respaldo\TS_TIENDA01_copia_seguridad.DBF"

PROMPT
PROMPT *** A CONTINUACION SE BORRARA EL DATAFILE TS_TIENDA01.DBF ***
PROMPT Comprueba arriba que la copia de seguridad existe. Ctrl+C cancela.
PAUSE Presiona Enter para simular la falla...

PROMPT ===== 3. FALLA CONTROLADA: se pierde el datafile =====
HOST del /Q "C:\APP\PETROSKY\PRODUCT\21C\ORADATA\XE\XEPDB1\TS_TIENDA01.DBF"
HOST dir "C:\APP\PETROSKY\PRODUCT\21C\ORADATA\XE\XEPDB1"

PROMPT ===== 4. Efecto de la falla (se espera ORA-00376 / ORA-01110) =====
SELECT COUNT(*) FROM tienda_app.clientes;

SPOOL OFF
PROMPT Falla simulada. Siguiente: recuperar con RMAN (08_recuperacion_rman.txt).

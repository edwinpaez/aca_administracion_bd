-- ============================================================
-- 09_verificar_recuperacion.sql
-- Objetivo : volver a poner TS_TIENDA en linea y comprobar que no se perdio
--            ningun dato, incluida la marca posterior al respaldo.
-- Ejecutar : como SYSDBA, despues de 08 (RMAN).
-- Salida   : C:\Proyecto_Oracle\evidencias\09_verificar_recuperacion.txt
-- Esperado : TS_TIENDA ONLINE; clientes 21; movimientos 50000; la marca existe.
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
COLUMN tablespace_name FORMAT A18
COLUMN file_name FORMAT A70
SPOOL C:\Proyecto_Oracle\evidencias\09_verificar_recuperacion.txt

ALTER SESSION SET CONTAINER = xepdb1;
ALTER TABLESPACE ts_tienda ONLINE;
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS fin_recuperacion FROM dual;

SELECT tablespace_name, status FROM dba_tablespaces WHERE tablespace_name = 'TS_TIENDA';
SELECT file_name, status FROM dba_data_files WHERE tablespace_name = 'TS_TIENDA';

SELECT COUNT(*) AS clientes FROM tienda_app.clientes;
SELECT COUNT(*) AS movimientos FROM tienda_app.movimientos_inventario;
SELECT id_cliente, nombre FROM tienda_app.clientes WHERE email = 'post.respaldo@correo.test';

SPOOL OFF

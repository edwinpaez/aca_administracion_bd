-- ============================================================
-- 12_automatizacion.sql
-- Objetivo : automatizar la depuracion de MOVIMIENTOS_INVENTARIO (problema
--            secundario 2): borrar movimientos de mas de 12 meses y dejar
--            constancia en LOG_DEPURACION_INVENTARIO. Se programa con
--            DBMS_SCHEDULER (1er dia de cada mes, 02:00) y se ejecuta una
--            vez ahora para demostrarlo.
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA), DESPUES del script 11.
-- *** MODIFICA DATOS: borra ~33.000 movimientos antiguos (solo laboratorio).
--     Hay un PAUSE antes de ejecutar; Ctrl+C cancela. ***
-- Salida   : C:\Proyecto_Oracle\evidencias\12_automatizacion.txt
-- Re-ejecutable: recrea procedimiento y job; la 2a ejecucion borra 0 filas.
-- Esperado : filas antes 50000 -> despues ~16.500; 1 fila OK en el log;
--            job habilitado con proxima ejecucion el dia 1 a las 02:00.
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
COLUMN job_name FORMAT A32
COLUMN repeat_interval FORMAT A45
COLUMN mensaje FORMAT A55
COLUMN status FORMAT A10
SPOOL C:\Proyecto_Oracle\evidencias\12_automatizacion.txt

ALTER SESSION SET CONTAINER = xepdb1;

PROMPT ===== 1. ANTES =====
SELECT COUNT(*) AS filas_total,
       SUM(CASE WHEN fecha_movimiento < ADD_MONTHS(TRUNC(SYSDATE), -12) THEN 1 ELSE 0 END) AS mas_de_12_meses,
       SUM(CASE WHEN fecha_movimiento >= ADD_MONTHS(TRUNC(SYSDATE), -12) THEN 1 ELSE 0 END) AS ultimos_12_meses
  FROM tienda_app.movimientos_inventario;
SELECT COUNT(*) AS filas_en_log FROM tienda_app.log_depuracion_inventario;

PROMPT ===== 2. Procedimiento de depuracion (parametro: meses a conservar) =====
CREATE OR REPLACE PROCEDURE tienda_app.sp_depurar_movimientos (p_meses IN NUMBER DEFAULT 12)
AS
  v_n   NUMBER;
  v_msg VARCHAR2(300);
BEGIN
  DELETE FROM tienda_app.movimientos_inventario
   WHERE fecha_movimiento < ADD_MONTHS(TRUNC(SYSDATE), -p_meses);
  v_n := SQL%ROWCOUNT;
  INSERT INTO tienda_app.log_depuracion_inventario (registros_eliminados, estado, mensaje)
  VALUES (v_n, 'OK', 'Eliminados movimientos con mas de ' || p_meses || ' meses');
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    v_msg := SUBSTR(SQLERRM, 1, 300);   -- SQLERRM no se puede usar directo en un INSERT
    ROLLBACK;
    INSERT INTO tienda_app.log_depuracion_inventario (registros_eliminados, estado, mensaje)
    VALUES (0, 'ERROR', v_msg);
    COMMIT;
    RAISE;
END;
/
SHOW ERRORS PROCEDURE tienda_app.sp_depurar_movimientos
SELECT object_name, status FROM dba_objects
 WHERE owner = 'TIENDA_APP' AND object_name = 'SP_DEPURAR_MOVIMIENTOS';

PROMPT ===== 3. Job programado (mensual, dia 1 a las 02:00) =====
BEGIN
  BEGIN
    DBMS_SCHEDULER.DROP_JOB('TIENDA_APP.JOB_DEPURAR_MOVIMIENTOS', force => TRUE);
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => 'TIENDA_APP.JOB_DEPURAR_MOVIMIENTOS',
    job_type        => 'STORED_PROCEDURE',
    job_action      => 'TIENDA_APP.SP_DEPURAR_MOVIMIENTOS',
    repeat_interval => 'FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=2;BYMINUTE=0;BYSECOND=0',
    enabled         => TRUE,
    comments        => 'Depura movimientos de inventario con mas de 12 meses');
END;
/
SELECT job_name, enabled, state, repeat_interval,
       TO_CHAR(next_run_date, 'YYYY-MM-DD HH24:MI') AS proxima_ejecucion
  FROM dba_scheduler_jobs WHERE owner = 'TIENDA_APP';

PROMPT
PROMPT *** A CONTINUACION SE EJECUTA EL JOB UNA VEZ: BORRA LOS MOVIMIENTOS DE MAS DE 12 MESES ***
PAUSE Presiona Enter para ejecutar la depuracion (Ctrl+C cancela)...

PROMPT ===== 4. Ejecutar el job ahora (misma sesion, sincrono) =====
EXEC DBMS_SCHEDULER.RUN_JOB('TIENDA_APP.JOB_DEPURAR_MOVIMIENTOS', use_current_session => TRUE);

PROMPT ===== 5. DESPUES =====
SELECT COUNT(*) AS filas_total,
       SUM(CASE WHEN fecha_movimiento < ADD_MONTHS(TRUNC(SYSDATE), -12) THEN 1 ELSE 0 END) AS mas_de_12_meses
  FROM tienda_app.movimientos_inventario;
SELECT id_log, TO_CHAR(fecha_ejecucion,'YYYY-MM-DD HH24:MI:SS') AS fecha,
       registros_eliminados, estado, mensaje
  FROM tienda_app.log_depuracion_inventario ORDER BY id_log;
SELECT job_name, status, TO_CHAR(log_date,'YYYY-MM-DD HH24:MI:SS') AS cuando
  FROM dba_scheduler_job_run_details
 WHERE owner = 'TIENDA_APP' AND job_name = 'JOB_DEPURAR_MOVIMIENTOS'
 ORDER BY log_date;

SPOOL OFF
PROMPT Listo. Siguiente: monitoreo y respaldo programado.

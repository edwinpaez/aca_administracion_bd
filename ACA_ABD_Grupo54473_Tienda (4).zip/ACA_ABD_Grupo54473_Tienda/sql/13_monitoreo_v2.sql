-- ============================================================
-- 13_monitoreo.sql
-- Objetivo : tablero de monitoreo del DBA con vistas del diccionario: semaforo
--            de alertas, espacio, FRA, respaldos, archivelogs, sesiones,
--            consultas mas costosas, segmentos y trabajos programados.
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA). Solo lectura (no modifica nada).
-- Salida   : C:\Proyecto_Oracle\evidencias\13_monitoreo.txt
-- Umbrales : FRA > 80 %, tablespace > 80 %, ultimo respaldo > 24 h => ALERTA.
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
COLUMN control FORMAT A32
COLUMN estado FORMAT A8
COLUMN name FORMAT A38
COLUMN tablespace_name FORMAT A16
COLUMN username FORMAT A16
COLUMN segment_name FORMAT A28
COLUMN segment_type FORMAT A14
COLUMN job_name FORMAT A28
COLUMN sql_text FORMAT A62
COLUMN input_type FORMAT A14
COLUMN status FORMAT A24
SPOOL C:\Proyecto_Oracle\evidencias\13_monitoreo.txt

SELECT TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS') AS fecha_monitoreo FROM dual;

PROMPT ===== A. Nivel de instancia (raiz del CDB) =====
ALTER SESSION SET CONTAINER = cdb$root;
SELECT name, log_mode, open_mode FROM v$database;
SELECT instance_name, status, TO_CHAR(startup_time,'YYYY-MM-DD HH24:MI') AS inicio FROM v$instance;

PROMPT >> Semaforo de alertas (FRA y respaldo)
SELECT 'FRA usada (%)' AS control,
       ROUND(space_used / space_limit * 100, 1) AS valor,
       CASE WHEN space_used / space_limit * 100 > 80 THEN 'ALERTA' ELSE 'OK' END AS estado
  FROM v$recovery_file_dest
UNION ALL
SELECT 'Horas desde el ultimo respaldo',
       ROUND((SYSDATE - MAX(end_time)) * 24, 1),
       CASE WHEN MAX(end_time) < SYSDATE - 1 THEN 'ALERTA' ELSE 'OK' END
  FROM v$rman_backup_job_details WHERE status LIKE 'COMPLETED%';

PROMPT >> FRA (area de recuperacion rapida)
SELECT name, ROUND(space_limit/1048576) AS limite_mb, ROUND(space_used/1048576) AS usado_mb,
       ROUND(space_reclaimable/1048576) AS recuperable_mb, number_of_files AS archivos
  FROM v$recovery_file_dest;

PROMPT >> Historial de respaldos RMAN
SELECT TO_CHAR(start_time,'YYYY-MM-DD HH24:MI') AS inicio, input_type, status,
       ROUND(elapsed_seconds) AS seg, ROUND(output_bytes/1048576) AS mb_salida
  FROM v$rman_backup_job_details ORDER BY start_time;

PROMPT >> Archivelogs generados en las ultimas 24 h
SELECT COUNT(*) AS archivelogs, ROUND(NVL(SUM(blocks*block_size),0)/1048576,1) AS mb
  FROM v$archived_log WHERE first_time > SYSDATE - 1;

PROMPT ===== B. Nivel de la PDB XEPDB1 (aplicacion) =====
ALTER SESSION SET CONTAINER = xepdb1;

PROMPT >> Espacio por tablespace (% sobre el tamano maximo con autoextend)
SELECT tablespace_name,
       ROUND(used_space * (SELECT TO_NUMBER(value) FROM v$parameter WHERE name = 'db_block_size') / 1048576, 1) AS usado_mb,
       ROUND(tablespace_size * (SELECT TO_NUMBER(value) FROM v$parameter WHERE name = 'db_block_size') / 1048576) AS maximo_mb,
       ROUND(used_percent, 1) AS pct_usado,
       CASE WHEN used_percent > 80 THEN 'ALERTA' ELSE 'OK' END AS estado
  FROM dba_tablespace_usage_metrics ORDER BY tablespace_name;

PROMPT >> Segmentos de TIENDA_APP (mayores primero)
SELECT segment_name, segment_type, ROUND(bytes/1048576, 2) AS mb
  FROM dba_segments WHERE owner = 'TIENDA_APP'
 ORDER BY bytes DESC FETCH FIRST 6 ROWS ONLY;

PROMPT >> Sesiones de usuario
SELECT username, status, COUNT(*) AS sesiones
  FROM v$session WHERE username IS NOT NULL GROUP BY username, status ORDER BY username;

PROMPT >> Consultas de TIENDA_APP con mas lecturas logicas
SELECT sql_id, executions AS ejec, buffer_gets AS buffers,
       ROUND(elapsed_time/1000000, 3) AS seg, SUBSTR(sql_text, 1, 62) AS sql_text
  FROM v$sql
 WHERE parsing_schema_name = 'TIENDA_APP' AND sql_text NOT LIKE '%v$sql%'
 ORDER BY buffer_gets DESC FETCH FIRST 5 ROWS ONLY;

PROMPT >> Trabajos programados y ultimo resultado
SELECT j.job_name, j.enabled, TO_CHAR(j.next_run_date,'YYYY-MM-DD HH24:MI') AS proxima,
       (SELECT d.status FROM dba_scheduler_job_run_details d
         WHERE d.owner = j.owner AND d.job_name = j.job_name
           AND d.log_id = (SELECT MAX(log_id) FROM dba_scheduler_job_run_details
                            WHERE owner = j.owner AND job_name = j.job_name)) AS ultimo_estado
  FROM dba_scheduler_jobs j WHERE j.owner = 'TIENDA_APP';

PROMPT >> Usuarios de laboratorio bloqueados o vencidos
SELECT username, account_status FROM dba_users
 WHERE username IN ('TIENDA_APP','USR_VENTAS','USR_INVENTARIO','USR_AUDITOR')
 ORDER BY username;

SPOOL OFF
PROMPT Listo. Opcional: abre EM Express (https://localhost:5500/em) y captura el tablero para el Pitch.

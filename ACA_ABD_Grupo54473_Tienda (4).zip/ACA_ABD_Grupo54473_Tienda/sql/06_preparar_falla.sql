-- ============================================================
-- 06_preparar_falla.sql
-- Objetivo : dejar el escenario listo para la falla controlada.
--            Inserta una fila "marca" DESPUES del respaldo, para demostrar
--            luego que la recuperacion NO pierde datos posteriores a el.
-- Ejecutar : como SYSDBA (CONNECT / AS SYSDBA). NO es destructivo.
-- Salida   : C:\Proyecto_Oracle\evidencias\06_preparar_falla.txt
-- No es idempotente: la marca tiene email unico; correrlo dos veces falla.
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
SPOOL C:\Proyecto_Oracle\evidencias\06_preparar_falla.txt

PROMPT ===== Estado antes de la marca =====
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS hora FROM dual;
ALTER SESSION SET CONTAINER = xepdb1;
SELECT COUNT(*) AS clientes FROM tienda_app.clientes;
SELECT COUNT(*) AS movimientos FROM tienda_app.movimientos_inventario;

PROMPT ===== Insertar la marca (posterior al respaldo) =====
INSERT INTO tienda_app.clientes (nombre, telefono, email)
VALUES ('Cliente post-respaldo', '3000000000', 'post.respaldo@correo.test');
COMMIT;
SELECT COUNT(*) AS clientes_con_marca FROM tienda_app.clientes;
SELECT id_cliente, nombre FROM tienda_app.clientes WHERE email = 'post.respaldo@correo.test';

PROMPT ===== Forzar el archivado del redo (en la raiz) =====
ALTER SESSION SET CONTAINER = cdb$root;
ALTER SYSTEM ARCHIVE LOG CURRENT;
SELECT MAX(sequence#) AS ultimo_archivelog FROM v$archived_log;

SPOOL OFF
PROMPT Listo. Esperado: clientes 20 -> 21 con la marca; movimientos 50000.

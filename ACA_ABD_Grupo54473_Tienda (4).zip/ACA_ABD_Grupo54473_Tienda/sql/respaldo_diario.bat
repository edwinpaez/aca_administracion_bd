@echo off
rem ============================================================
rem respaldo_diario.bat - respaldo RMAN programado (ver 14_respaldo_diario.txt)
rem El resultado se agrega a evidencias\14_respaldo_diario.log
rem ============================================================
set ORACLE_HOME=C:\app\Petrosky\product\21c\dbhomeXE
set ORACLE_SID=XE
set NLS_DATE_FORMAT=YYYY-MM-DD HH24:MI:SS
"%ORACLE_HOME%\bin\rman" target / cmdfile=C:\Proyecto_Oracle\sql\14_respaldo_diario.txt log=C:\Proyecto_Oracle\evidencias\14_respaldo_diario.log append
echo Codigo de salida: %ERRORLEVEL% >> C:\Proyecto_Oracle\evidencias\14_respaldo_diario.log
exit /b %ERRORLEVEL%

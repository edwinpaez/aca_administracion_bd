@echo off
REM ============================================================
REM 15_exportar_datapump.bat  (guardar como 15_exportar_datapump.bat)
REM Objetivo : exportar el esquema TIENDA_APP con Data Pump = archivo de respaldo
REM            de la base para la entrega. Pide la clave de TIENDA_APP (oculta).
REM Antes    : ejecutar 15_datapump_directorio.sql como SYSDBA.
REM Salida   : C:\Proyecto_Oracle\respaldo\datapump\tienda_app.dmp
REM            C:\Proyecto_Oracle\respaldo\datapump\exp_tienda_app.log
REM ============================================================
set ORACLE_HOME=C:\app\Petrosky\product\21c\dbhomeXE
set PATH=%ORACLE_HOME%\bin;%PATH%
if not exist C:\Proyecto_Oracle\respaldo\datapump mkdir C:\Proyecto_Oracle\respaldo\datapump
if exist C:\Proyecto_Oracle\respaldo\datapump\tienda_app.dmp del C:\Proyecto_Oracle\respaldo\datapump\tienda_app.dmp
expdp tienda_app@localhost:1521/XEPDB1 schemas=TIENDA_APP directory=DP_TIENDA dumpfile=tienda_app.dmp logfile=exp_tienda_app.log
echo Codigo de salida: %ERRORLEVEL%
copy C:\Proyecto_Oracle\respaldo\datapump\exp_tienda_app.log C:\Proyecto_Oracle\evidencias\15_exp_tienda_app.log
dir C:\Proyecto_Oracle\respaldo\datapump
pause

-- ============================================================
-- 03_diagnostico_recursos.sql
-- Objetivo : capturar el ESTADO INICIAL ("antes") de la BD:
--            version, modo de archivado, respaldos existentes,
--            tablespaces/datafiles, tamano de segmentos, usuarios y permisos.
--            Es la evidencia del diagnostico DBA y de la gestion de recursos.
-- Ejecutar : conectado como SYSDBA (CONNECT / AS SYSDBA), en la raiz.
--            Requiere que exista la carpeta C:\Proyecto_Oracle\evidencias
-- Salida   : C:\Proyecto_Oracle\evidencias\03_diagnostico_antes.txt
-- Solo lectura: no modifica nada.
-- ============================================================
SET LINESIZE 200
SET PAGESIZE 100
SET TRIMSPOOL ON
SET VERIFY OFF
COLUMN banner_full FORMAT A80
COLUMN file_name FORMAT A70
COLUMN tablespace_name FORMAT A18
COLUMN segment_name FORMAT A30
COLUMN username FORMAT A18
COLUMN grantee FORMAT A15
COLUMN privilege FORMAT A25
COLUMN default_tablespace FORMAT A18

SPOOL C:\Proyecto_Oracle\evidencias\03_diagnostico_antes.txt

PROMPT ===== 0. Fecha de captura =====
SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS fecha_captura FROM dual;

PROMPT ===== 1. Version e instancia =====
SELECT banner_full FROM v$version;
SELECT instance_name, status, TO_CHAR(startup_time, 'YYYY-MM-DD HH24:MI') AS inicio FROM v$instance;

PROMPT ===== 2. Modo de archivado (clave para recuperacion) =====
SELECT log_mode FROM v$database;

PROMPT ===== 3. Respaldos registrados en el control file (0 = nunca se hizo respaldo) =====
SELECT COUNT(*) AS respaldos_registrados FROM v$backup_set;

PROMPT ===== 4. PDBs =====
SELECT name, open_mode FROM v$pdbs;

-- A partir de aqui se consulta la PDB del proyecto
ALTER SESSION SET CONTAINER = xepdb1;

PROMPT ===== 5. Datafiles de la PDB =====
SELECT tablespace_name, file_name, ROUND(bytes/1024/1024, 1) AS mb,
       autoextensible, ROUND(maxbytes/1024/1024, 1) AS max_mb, status
  FROM dba_data_files
 ORDER BY tablespace_name;

PROMPT ===== 6. Espacio por tablespace (MB) =====
SELECT d.tablespace_name,
       ROUND(d.mb, 1) AS asignado_mb,
       ROUND(NVL(f.mb, 0), 1) AS libre_mb,
       ROUND(d.mb - NVL(f.mb, 0), 1) AS usado_mb
  FROM (SELECT tablespace_name, SUM(bytes)/1024/1024 AS mb
          FROM dba_data_files GROUP BY tablespace_name) d
  LEFT JOIN (SELECT tablespace_name, SUM(bytes)/1024/1024 AS mb
               FROM dba_free_space GROUP BY tablespace_name) f
    ON d.tablespace_name = f.tablespace_name
 ORDER BY d.tablespace_name;

PROMPT ===== 7. Segmentos mas grandes del esquema TIENDA_APP =====
SELECT segment_name, segment_type, ROUND(bytes/1024/1024, 2) AS mb
  FROM dba_segments
 WHERE owner = 'TIENDA_APP'
 ORDER BY bytes DESC
 FETCH FIRST 10 ROWS ONLY;

PROMPT ===== 8. Usuarios no internos de la PDB =====
SELECT username, account_status, default_tablespace
  FROM dba_users
 WHERE oracle_maintained = 'N'
 ORDER BY username;

PROMPT ===== 9. Privilegios de sistema de TIENDA_APP =====
SELECT grantee, privilege FROM dba_sys_privs WHERE grantee = 'TIENDA_APP' ORDER BY privilege;

SPOOL OFF
PROMPT Evidencia guardada en C:\Proyecto_Oracle\evidencias\03_diagnostico_antes.txt
